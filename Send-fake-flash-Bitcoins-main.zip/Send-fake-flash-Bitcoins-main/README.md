# Send-fake-flash-Bitcoins
Flash Bitcoin Sender is a tool which help you send Fake Bitcoin into the blockchain as a prank for your friends. The coins will act just like the real coin but will vanish from blockchain after 60 days.
